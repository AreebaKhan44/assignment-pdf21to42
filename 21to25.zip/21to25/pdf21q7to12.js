//7. Write a program to replace the “Hyder” to “Islam” in the word “Hyderabad” and display the result in your browser.

document.write("Project 7" + "<br>"+ "replacement function" +"<br>" +"</br>");
var city1= "Hyderabad";

    document.write("city:" + city1 + "<br>");
    document.write("After replacement:" + city1.replace("Hyderabad","Islamabad"+ "<br>"+"</br>"));
//qno7
    var city="Hyderabad";
    alert(`After Replacement: ${city.replace("Hyder","Islam")}`)


   // 8. Write a program to replace all occurrences of “and” in the string with “&” and display the result in your browser. var message = “Ali and Sami are best friends. They play cricket and football together.”;

   var message="Ali and sami are best friends.They play cricket and football together \n"
   document.write(message.replace("and", "&"))




    //12. Write a program that converts the variable num to string. var num = 35.36 ; Remove the dot to display “3536” display in your browser

var num = 35.36;
var without = num.toString().replace(".", ""); 
alert(without);

//10. Write a program that takes user input. Convert and show the input in capital letters.


var a=prompt ("User input enter string in smallcase letter");
alert(a.toUpperCase());

//11. Write a program that takes user input. Convert and show the input in title case
var b=prompt("user input enter string  uppercase letter")
alert(b.toLowerCase());



//9. Write a program that converts a string “472” to a number 472. Display the values & types in your browser

document.write("value:" + "472"+ "<br>" + "type:"+ "string" +"<br>"+ "value:" + "472"+"<br>"+ "type:" + "number"+  +"<br>" );
var value= "472\n";

    document.write("4" + "72" + "<br>");
    document.write("value type:" + value.tostring("4","72"+ "<br>"+"</br>"));
    document.write("value type:" + value.toNumber("4","72"+ "<br>"+"</br>"));



