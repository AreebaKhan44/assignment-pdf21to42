
// qno18

function count(main_str, sub_str) 
{
main_str += '';
sub_str += '';

if (sub_str.length <= 0) 
{
    return main_str.length + 1;
}

   subStr = sub_str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
   return (main_str.match(new RegExp(subStr, 'gi')) || []).length;
}

console.log(count("The quick brown fox jumps over the lazy dog", 'the'));
console.log(count("The quick brown fox jumps over the lazy dog", 'fox',false));



//14. You have an array A = [cake”, “apple pie”, “cookie”, “chips”, “patties”] Write a program to enable “search by user input” in an array. After searching, prompt the user whether the given item is found in the list or not. Note: Perform case insensitive search. Whether the user enters cookie, Cookie, COOKIE or coOkIE, program should inform about its availability. Example:

var items=["cake","apple pie","cookie","chips","patties"];
var useritem =prompt("Enter your item")
if (useritem === items[0]) {
alert("cake is available  at index 0 in our bakery");
 }
 else if (useritem === items[1]) {
 alert("apple pie is available at index 1 in our bakery");
}
 else if (useritem === items[2]) {
alert("cookie is available at index 2 in or bakery");
 }
 else if (useritem === items[3]) {
 alert("chips is available at index 3 in our bakery");
 }
 else if (useritem === items[4]) {
 alert("patties is available at index 4 in our bakery");
 }

 else {
 alert("we are sorry this item is not available in our bakery");
 }

 //13) Write a program to take user input and store username in a variable. If the username contains
 //any special symbol among [@ . , !], prompt the user to enter a valid username. For character 
 //codes of [@ .

 //13)Note: ASCII code of ! is 33 ASCII code of , is 44 ASCII code of . is 46 ASCII code of @ is 64




 var userName=prompt("Enter your username: ");
checkValidName(userName);
function checkValidName(un)
{
    var message;
    var split=[];
    var arr=[];
    for(var i=0;i<un.length;i++)
    {
        split[i]=un.split("&nbsp;");
        arr[i]=un.charCodeAt(i);
        if(arr[i]!=33||arr[i]!=44||arr[i]!=46||arr[i]!=64)
        {
                message="Correct User Name";
        }
        while(arr[i]==33||arr[i]==44||arr[i]==46||arr[i]==64)
        {
            alert("please enter a valid userName");                                                                                                                   
            userName=prompt("Enter your Input: ");
            split[i]=un.split("&nbsp;");
            arr[i]=un.charCodeAt(i);
            if(arr[i]!=33||arr[i]!=44||arr[i]!=46||arr[i]!=64)
            {
                message="correct in";
                break;
            }
        }

    }
    alert(message);
}

