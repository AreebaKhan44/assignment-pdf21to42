
//Q11. Write a custom function power ( a, b ), to calculate the value of a raised to b.
function exp(a, b) {
    var ans = 1;
    for (var i = 1; i <= b; i++) {
        ans = a * ans;
    }
    return ans;
}
 c = window.prompt("Enter a: ");
 d = window.prompt("Enter b: ");
console.log(exp(c, d));

//Q2  2. Any year is entered through the keyboard. Write a function to determine whether the year is a leap year or not. Leap years 
//..., 2012, 2016, 2020, …
function leapyear(year) {
    return (year % 100 === 0) ? (year % 400 === 0) : (year % 4 === 0);
}
 yr = window.prompt("Enter year: ");
console.log(leapyear(yr));

//Q33. If the lengths of the sides of a triangle are denoted by a, b, and c, then area of triangle is given by
//area = S(S − a)(S − b)(S − c)
//where, S = ( a + b + c ) / 2
//Calculate area of triangle using 2 functions

function areaa(a, b, c) {
    function SS(a, b, c) {
        let x = 0;
        x = (a + b + c);
        console.log("value os s ", x);
        return (x);
    }
    let ar;
    let s = SS(a, b, c);


    ar = Math.sqrt(s * (s - a) * (s - b) * (s - c));

    return (ar);
}
var a = prompt("Enter a: ");
var b = prompt("Enter b: ");
var c = prompt("Enter c: ");
console.log("Area", areaa(parseInt(a), parseInt(b), parseInt(c)));


//Q4  Write a function that receives marks received by a student in 3 subjects and returns the average and percentage of these
//marks. there should be 3 functions one is the mainFunction and other are for average and percentage. Call those functions from mainFunction and display result in mainFunction.

function result(a, b, c) {
    var avg, per;
    avg = parseFloat(a + b + c) / 3.0;
    //per = parseFloat((avg) / 300.0) * 100;
    per = parseInt(a+b+c)*100/300; 
    console.log("The Average :", avg);
    console.log(" The Percentage:", per);
    return (null);
}
var a = prompt("Enter the marks of subject 1:  ");
var b = prompt("Enter the marks of subject 2:  ");
var c = prompt("Enter the marks of subject 3:  ");
console.log(result(parseFloat(a), parseFloat(a), parseFloat(a)));

//Q5  5. You have learned the function indexOf. Code your own custom function that will perform 
//the same functionality. You can code for single character as of now.

function myIndexOf(collection, target) {
    for (var val in collection) {
        if (collection[val] === target) {
            return val;
        }
    }
}
var collection = [1, 4, 5, 7, 8, 9];
var target = 5;
var i = myIndexOf(collection, target);
console.log(i);

//Q6 6. Write a function to delete all vowels from a sentence. Assume that the sentence is not
// more than 25 characters long.

function remVowel(str) {
    let al = ['a', 'e', 'i', 'o', 'u',
        'A', 'E', 'I', 'O', 'U'];
    let result = "";

    for (let i = 0; i < str.length; i++) {

        if (!al.includes(str[i])) {
            result += str[i];
        }
    }
    return result;
}

// Driver code
let str = "areeba Naz khan";
console.log(remVowel(str));

//Q7  Write a function with switch statement to count the number of occurrences of any two vowels
// in succession in a line of text. For example, in the sentence
//“Pleases read this application and give me gratuity”
//Such occurrences are ea, ea, ui.

function findOccurrences() {
    var str = "Pleases read this application and give me gratuity";
    var res = str.match(/[aeiou]{2}/g);
    return res ? res.length : 0;
}

var found = findOccurrences();

console.log(found);

//Q8  8. The distance between two cities (in km.) is input through the keyboard. 
// Write four functions to convert and print this distance in meters, feet, inches and centimeters.


function meter(a, b) {
    let w, w2;
    w = a * 1000;
    w2 = b * 1000;
    return (w, w2);
}

function cm(a, b) {
    let w, w2;
    w = a * 1000 * 100;
    w2 = b * 1000 * 100;
    return (w, w2);
}
function feet(a, b, c) {
    let w, w2;
    w = a * 3280.84;
    w2 = b * 3280.84;
    return (w, w2);
}
function inches(a, b, c) {
    let w, w2;
    w = a * 39370.08;
    w2 = b * 39370.08;
    return (w, w2);
}


var a = prompt("Enter distance of City 1 in km: ");
var b = prompt("Enter distance of City 2 in km: ");
console.log("distance in meter:", meter(parseFloat(a), parseFloat(b)));
console.log("distance in centimeter:", cm(parseFloat(a), parseFloat(b)));
console.log("distance in feet:", feet(parseFloat(a), parseFloat(b)));
console.log("distance in inches:", inches(parseFloat(a), parseFloat(b)));

//Q9 9. Write a program to calculate overtime pay of employees. Overtime is paid at the rate of 
//Rs. 12.00 per hour for every hour worked above 40 hours. Assume that employees do not work for fractional part of an hour.


var working_hours = prompt("Enter the working hours of employee ");

if (parseFloat(working_hours) > 40) {
    var over_time = working_hours - 40;
    var over_time_pay = parseFloat(over_time) * 12.00;
    console.log("Employee No overtime pay is:", parseFloat(over_time_pay));
}
else
    console.log("You have to work for more than 40 hours to get over time pay");

//Q10 10. A cashier has currency notes of denominations 10, 50 and 100. If the amount to be withdrawn 
//is input through the keyboard in hundreds, find the total number of currency notes of each denomination the cashier will have to give to the withdrawer.



var t = prompt("Input notes in hundreds ");
var t1, t2, t3, m1, m2, m3;

t3 = parseInt(t) / 100;
m3 = t3;

t2 = (t - parseInt(m3) * 100) / 50;
m2 = t2;

t1 = (t - (parseInt(m3) * 100 + parseInt(m2) * 50)) / 10;
m1 = t1;
console.log("The no of 100 notes is", parseInt(m3));
console.log("The no of 50 notes is", parseInt(m2));
console.log("The no of 10 notes is", parseInt(m1));


